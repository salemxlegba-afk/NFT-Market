# NFT Market — Handoff

## Current state
- Discord bot prototype is implemented in `main.py` / `bot_runner.py`.
- Existing commands: `/sell`, `/buy`, `/matches`, `/cancel`, `/wallet`, `/wallet-status`, `/wallet-remove`, `/help`, `/ping`.
- Buyer/seller matching and temporary private deal channels are implemented.
- Solana wallet ownership/control verification uses Ed25519 signatures; no seed phrase or private key is requested.
- Wallet verification web frontend is in `src/components/WalletVerificationPortal.tsx` with Solana verification helpers in `src/lib/solana-verify.ts`.
- Netlify configuration and wallet functions are in `netlify.toml` and `netlify/functions/`.
- Supabase persistence preparation is in `schema.sql` and `supabase_store.py`.
- Oracle/systemd deployment preparation is in `systemd/` and `scripts/install_oracle_vm.sh`.
- A public Netlify wallet verification site has been deployed at: https://nftmarketwallet.netlify.app

## Environment variables (NOT included in this archive)
- `DISCORD_TOKEN`
- `SUPABASE_URL`
- `SUPABASE_SERVICE_KEY` (server-only secret; never commit/share publicly)
- `VITE_SUPABASE_ANON_KEY` / publishable key as currently named by the project
- `WALLET_VERIFY_BASE_URL=https://nftmarketwallet.netlify.app`
- `WALLET_WEB_PORT`

## Important security rule
Never put Discord tokens, Supabase secret/service keys, wallet seed phrases, or private keys into this archive, GitHub, frontend code, or chat.

## Immediate next steps
1. Verify `WALLET_VERIFY_BASE_URL` is configured for the bot.
2. Test `/wallet` from Discord and confirm it generates a real session URL under `https://nftmarketwallet.netlify.app/wallet/verify?session=...`.
3. Confirm Supabase schema/persistence is active.
4. Deploy the Discord bot to a genuinely persistent/free-tier host (target: Oracle Cloud Always Free if available) so it does not depend on AI Studio being open.
5. Keep the existing matching and wallet-verification functionality intact.

## Hosting note
AI Studio is a development environment and may pause its container. It must not be treated as the permanent 24/7 host for the Discord Gateway bot.
