export interface VerificationSession {
  token: string;
  discordUserId: string;
  nonce: string;
  expiresAt: string;
}

export interface VerifiedWalletRecord {
  discordUserId: string;
  publicKey: string;
  verifiedAt: string;
  signature: string;
  algorithm: 'ed25519';
}

export interface BotCommandInfo {
  command: string;
  description: string;
  scope: string;
  category: 'Wallet' | 'Market' | 'Utility';
}
